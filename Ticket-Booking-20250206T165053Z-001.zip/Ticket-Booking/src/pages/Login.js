import React, { useState } from 'react';
import { Button, Input, Card, Container, Spacer } from '@nextui-org/react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase/firebaseConfig';

function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null);

    const handleLogin = async () => {
        try {
            await signInWithEmailAndPassword(auth, email, password);
        } catch (err) {
            setError(err.message);
        }
    };

    return (
        <Container>
            <Card>
                <h2>Login</h2>
                {error && <p>{error}</p>}
                <Input type="email" placeholder="Email" onChange={(e) => setEmail(e.target.value)} />
                <Spacer y={0.5} />
                <Input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
                <Spacer y={1} />
                <Button onClick={handleLogin}>Login</Button>
            </Card>
        </Container>
    );
}

export default Login;
