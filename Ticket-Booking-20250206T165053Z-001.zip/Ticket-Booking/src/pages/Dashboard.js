import React, { useEffect, useState } from 'react';
import { getDocs, collection, addDoc, updateDoc, deleteDoc, doc } from 'firebase/firestore';
import { db, auth } from '../firebase/firebaseConfig';
import TicketForm from '../components/TicketForm';
import TicketTable from '../components/TicketTable';

function Dashboard() {
    const [tickets, setTickets] = useState([]);
    const [userRole, setUserRole] = useState('');

    useEffect(() => {
        const fetchTickets = async () => {
            const querySnapshot = await getDocs(collection(db, 'tickets'));
            setTickets(querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        };
        fetchTickets();
    }, []);

    useEffect(() => {
        const user = auth.currentUser;
        if (user) {
            setUserRole(user.email === 'customer@support.com' ? 'customer' : 'agent');
        }
    }, []);

    const handleCreateTicket = async (ticketData) => {
        await addDoc(collection(db, 'tickets'), { ...ticketData, status: 'Open', createdBy: auth.currentUser.email });
    };

    const handleUpdateStatus = async (id) => {
        if (userRole !== 'agent') return;
        const ticketRef = doc(db, 'tickets', id);
        await updateDoc(ticketRef, { status: 'Resolved' });
    };

    const handleDeleteTicket = async (id) => {
        if (userRole !== 'customer') return;
        await deleteDoc(doc(db, 'tickets', id));
    };

    return (
        <div>
            {userRole === 'customer' && <TicketForm onSubmit={handleCreateTicket} />}
            <TicketTable tickets={tickets} onResolve={handleUpdateStatus} onDelete={handleDeleteTicket} userRole={userRole} />
        </div>
    );
}

export default Dashboard;
