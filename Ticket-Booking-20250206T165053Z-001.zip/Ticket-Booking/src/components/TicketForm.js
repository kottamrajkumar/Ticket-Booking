import React, { useState } from 'react';
import { Input, Button, Dropdown, Modal, Spacer } from '@nextui-org/react';

function TicketForm({ onSubmit }) {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [priority, setPriority] = useState('Low');
    const [category, setCategory] = useState('General');
    const [attachment, setAttachment] = useState(null);

    const handleSubmit = async () => {
        await onSubmit({ title, description, priority, category, attachment });
    };

    return (
        <Modal>
            <h3>Create Ticket</h3>
            <Input label="Title" onChange={(e) => setTitle(e.target.value)} />
            <Spacer y={0.5} />
            <Input label="Description" onChange={(e) => setDescription(e.target.value)} />
            <Dropdown label="Priority" onChange={(e) => setPriority(e.target.value)}>
                <Dropdown.Item>Low</Dropdown.Item>
                <Dropdown.Item>Medium</Dropdown.Item>
                <Dropdown.Item>High</Dropdown.Item>
            </Dropdown>
            <Dropdown label="Category" onChange={(e) => setCategory(e.target.value)}>
                <Dropdown.Item>General</Dropdown.Item>
                <Dropdown.Item>Technical</Dropdown.Item>
            </Dropdown>
            <Input type="file" onChange={(e) => setAttachment(e.target.files[0])} />
            <Button onClick={handleSubmit}>Submit</Button>
        </Modal>
    );
}

export default TicketForm;
