import React from 'react';
import { Navbar, Text } from '@nextui-org/react';
import { Link } from 'react-router-dom';

function Sidebar() {
    return (
        <Navbar variant="sticky">
            <Navbar.Brand>
                <Text b color="inherit">Ticketing System</Text>
            </Navbar.Brand>
            <Navbar.Content>
                <Navbar.Link as={Link} to="/dashboard">Dashboard</Navbar.Link>
                <Navbar.Link as={Link} to="/login">Logout</Navbar.Link>
            </Navbar.Content>
        </Navbar>
    );
}

export default Sidebar;
