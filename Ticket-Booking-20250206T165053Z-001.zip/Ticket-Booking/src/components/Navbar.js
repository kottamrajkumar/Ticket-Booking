import React from 'react';
import { Navbar } from '@nextui-org/react';

function CustomNavbar() {
    return (
        <Navbar variant="sticky">
            <Navbar.Brand>Ticketing System</Navbar.Brand>
            <Navbar.Content>
                {/* Add navigation items if needed */}
            </Navbar.Content>
        </Navbar>
    );
}

export default CustomNavbar;
