import React from 'react';
import { Table, Button } from '@nextui-org/react';

function TicketTable({ tickets, onResolve, onDelete, userRole }) {
    return (
        <Table aria-label="Ticket Table">
            <Table.Header>
                <Table.Column>ID</Table.Column>
                <Table.Column>Title</Table.Column>
                <Table.Column>Description</Table.Column>
                <Table.Column>Priority</Table.Column>
                <Table.Column>Status</Table.Column>
                <Table.Column>Actions</Table.Column>
            </Table.Header>
            <Table.Body>
                {tickets.map(ticket => (
                    <Table.Row key={ticket.id}>
                        <Table.Cell>{ticket.id}</Table.Cell>
                        <Table.Cell>{ticket.title}</Table.Cell>
                        <Table.Cell>{ticket.description}</Table.Cell>
                        <Table.Cell>{ticket.priority}</Table.Cell>
                        <Table.Cell>{ticket.status}</Table.Cell>
                        <Table.Cell>
                            {userRole === 'agent' && <Button size="xs" onClick={() => onResolve(ticket.id)}>Resolve</Button>}
                            {userRole === 'customer' && <Button size="xs" onClick={() => onDelete(ticket.id)}>Delete</Button>}
                        </Table.Cell>
                    </Table.Row>
                ))}
            </Table.Body>
        </Table>
    );
}

export default TicketTable;
